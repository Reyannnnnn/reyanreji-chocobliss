from django.contrib import admin
from .models import Product, Cart, Favourite  # ✅ Import all necessary models

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'category', 'is_featured', 'created_at')
    list_filter = ('category', 'is_featured')
    search_fields = ('name', 'description')
admin.site.register(Cart)
admin.site.register(Favourite)