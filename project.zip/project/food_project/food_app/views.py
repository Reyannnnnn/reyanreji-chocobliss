from django.shortcuts import render
from .models import Product  # or whatever your model is
from django.shortcuts import render, redirect
from .models import Cart
from django.contrib.auth.decorators import login_required
from django.shortcuts import  get_object_or_404
from django.contrib import messages
from .models import Favourite
@login_required(login_url='login')
def home(request):
    
    return render(request, 'food_app/home.html')
        



CATEGORY_LABELS = {
    'dark': 'Dark Chocolate',
    'truffles': 'truffles',
    'specials': 'specials',
    'gift': 'Gift Box',
    'fest': 'festivals',
    'giftc': 'collection',
}



def shop_view(request):
    query = request.GET.get('q')
    products = Product.objects.all()

    if query:
        products = products.filter(name__icontains=query)

    # Group by categories
    categorized_products = {}
    for product in products:
        category_name = product.get_category_display() if hasattr(product, 'get_category_display') else product.category
        if category_name not in categorized_products:
            categorized_products[category_name] = []
        categorized_products[category_name].append(product)

    return render(request, 'food_app/shop.html', {'categorized_products': categorized_products})



def about_view(request):
    return render(request, 'food_app/about.html')



def favourites(request):
    # Dummy query: filter based on user session or hardcoded list
    # Replace with actual logic once user system is integrated
    favourites = Product.objects.filter(is_favourite=True)  # Example
    return render(request, 'food_app/favourites.html', {'favourites': favourites})



def contact_view(request):
    return render(request, 'food_app/contact.html') 


@login_required
def cart_view(request):
    cart_items = Cart.objects.filter(user=request.user)
    total = sum(item.total_price() for item in cart_items)
    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total': total
    })


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)

    if not created:
        cart_item.quantity += 1
        cart_item.save()
        messages.success(request, f"Updated quantity for {product.name} in cart.")
    else:
        messages.success(request, f"{product.name} added to cart.")

    return redirect('cart')

@login_required
def favourites(request):
    favourites = Favourite.objects.filter(user=request.user).select_related('product')
    return render(request, 'favourites.html', {'favourites': favourites})


@login_required
def add_to_favourites(request, product_id):
    if request.user.is_authenticated:
        product = get_object_or_404(Product, id=product_id)
        Favourite.objects.get_or_create(user=request.user, product=product)
        messages.success(request, f"'{product.name}' added to your favourites ❤️")
    else:
        messages.warning(request, "Please log in to add to favourites.")
    return redirect(request.META.get('HTTP_REFERER', 'home'))

def gift_view(request):
    gift_products = Product.objects.filter(category='gift')  # use your category key
    return render(request, 'food_app/gift.html', {'gift_products': gift_products})


