from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about_view, name='about'),

    path('favourites/', views.favourites, name='favourites'),

    path('shop/', views.shop_view, name='shop'),
     path('cart/', views.cart_view, name='cart'), 
     path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
     path('favourites/', views.favourites, name='favourites'),
     path('add-to-favourites/<int:product_id>/', views.add_to_favourites, name='add_to_favourites'),
     path('contact/', views.contact_view, name='contact'),
     path('gift/', views.gift_view, name='gift'),
   
]